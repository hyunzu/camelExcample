package camel;

import org.apache.camel.CamelContext;
import org.apache.camel.EndpointInject;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.builder.AdviceWith;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.spring.junit5.CamelSpringBootTest;
import org.apache.camel.test.spring.junit5.MockEndpoints;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@CamelSpringBootTest
@MockEndpoints("amqp:queue:*")
public class MySpringBootApplicationTest {

	@Autowired
	private CamelContext camelContext;

	@Autowired
	private ProducerTemplate producerTemplate;

	@EndpointInject("mock:amqp:queue:AMQ.store.dev::smfl")
    private MockEndpoint mockAmqpEndpoint;

	@Test
    void testCamelRoute() throws InterruptedException {
        // テスト対象のメッセージを作成して送信
        //producerTemplate.sendBodyAndHeader("servlet:/smfl/dev", "Test Message", "Content-Type", "application/json");
		Exchange lAuthRequest = createExchangeWithBody("test body");
		producerTemplate.send("servlet:/smfl/dev", );

        // メッセージがルートを通過するかどうかを検証
        mockAmqpEndpoint.expectedMessageCount(1);
        mockAmqpEndpoint.assertIsSatisfied();
    }
}
