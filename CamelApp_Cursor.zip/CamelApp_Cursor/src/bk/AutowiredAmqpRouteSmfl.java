package camel;

import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Expression;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.language.bean.BeanExpression;
import org.apache.camel.model.RouteDefinition;
import org.apache.qpid.jms.JmsConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;


@Component
public class AutowiredAmqpRouteSmfl extends RouteBuilder {

    //AMQPの接続設定クラスのインスタンス化
    @Autowired
    JmsConnectionFactory amqpConnectionFactorySmfl;

    @Value("${AMQP_QUEUE_NAME_SMFL}")
    private String queueName;

    @Value("${HTTPS_BASE_URL_SMFL}")
    private String baseUrl;

    @Autowired
    private CamelContext camelContext;

    //CamelのAMQP接続の関数に値を代入
    @Bean
    public org.apache.camel.component.amqp.AMQPComponent amqpConnectionSmfl() {
        org.apache.camel.component.amqp.AMQPComponent amqp = new org.apache.camel.component.amqp.AMQPComponent();
        amqp.setConnectionFactory(amqpConnectionFactorySmfl);

        System.out.println("DEBUG:amqpConnectionFactorySmfl="+amqpConnectionFactorySmfl+",AMQPComponent="+amqp);

        // Camel ContextにAMQP Componentを登録
        //TODO 設計書にはない
        camelContext.addComponent("amqp", amqp);

        return amqp;
    }


    @Override
    public void configure() {

        System.out.println("baseUrl="+baseUrl);
        //servlet⇒direct:message
        from("servlet:" + baseUrl + "?matchOnUriPrefix=true&httpMethodRestrict=POST")
        .log("DEBUG:Sevlet ⇒ direct message:"+"${headers}" + "${body}")
        .to("direct:message")
        .end();

        System.out.println("queueName="+queueName);
        //direct:message⇒amqp:queue
        from("direct:message")
        .setExchangePattern(ExchangePattern.InOnly)
        .to("amqp:queue:" + queueName)
        .log("DEBUG:direct:message ⇒ amqp:queue:"+"${headers}" + "${body}")
        .end();


    //     //TODO 判断条件
    //     boolean flag = (1==1);

    //     if(flag){
    //         //TODO 正常なメッセージ
    //         Expression okExpression = null;

    //         //正常なレスポンス
    //         routeDefinition.setHeader(Exchange.HTTP_RESPONSE_CODE, constant("200"))
    //         .setBody(okExpression);

    //     } else if (flag) {
    //         //TODO エラーメッセージ
    //         Expression errorExpression = null;

    //         //timeoutエラー
    //         routeDefinition.setHeader(Exchange.HTTP_RESPONSE_CODE, constant("504"))
    //         .setBody(errorExpression)
    //         .log(LoggingLevel.ERROR, "504 Gateway Time-out");
    //     } else {
    //         //TODO エラーメッセージ
    //         Expression errorExpression = null;

    //         //500エラー
    //         routeDefinition.setHeader(Exchange.HTTP_RESPONSE_CODE, constant("500"))
    //         .setBody(errorExpression)
    //         .log(LoggingLevel.ERROR, "500 Internal Server Error");
    //     }
    }

}
