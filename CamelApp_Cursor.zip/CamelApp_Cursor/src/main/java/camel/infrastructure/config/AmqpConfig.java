package camel.infrastructure.config;

import org.apache.qpid.jms.JmsConnectionFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

/**
 * A bean that returns a message when you call the {@link #saySomething()} method.
 * <p/>
 * Uses <tt>@Component("myBean")</tt> to register this bean with the name <tt>myBean</tt>
 * that we use in the Camel route to lookup this bean.
 */
//@Component("myBean")

@Configuration
public class AmqpConfig {

    //AMQホスト(SMFL/みらい)
    @Value("${AMQP_HOST_SMFL}")
    private String amqpHostSmfl;
    @Value("${AMQP_HOST_FTR}")
    private String amqpHostFtr;
    //AMQポート(SMFL/みらい)
    @Value("${AMQP_SERVICE_PORT_SMFL}")
    private String amqpPortSmfl;
    @Value("${AMQP_SERVICE_PORT_FTR}")
    private String amqpPortFtr;
    //ユーザー名(SMFL/みらい)
    @Value("${AMQP_SERVICE_USERNAME_SMFL}")
    private String userNameSmfl;
    @Value("${AMQP_SERVICE_USERNAME_FTR}")
    private String userNameFtr;
    //パスワード(SMFL/みらい)
    @Value("${AMQP_SERVICE_PASSWORD_SMFL}")
    private String passSmfl;
    @Value("${AMQP_SERVICE_PASSWORD_FTR}")
    private String passFtr;
    //接続先URI(SMFL/みらい)
    @Value("${AMQP_REMOTE_URI_SMFL}")
    private String remoteUriSmfl;
    @Value("${AMQP_REMOTE_URI_FTR}")
    private String remoteUriFtr;

    //AMQホスト(SMFL/みらい)
    public String getAmqpHostSmfl() {
        return amqpHostSmfl;
    }
    public void setAmqpHostSmfl(String amqpHostSmfl) {
        this.amqpHostSmfl = amqpHostSmfl;
    }
    public String getAmqpHostFtr() {
        return amqpHostFtr;
    }
    public void setAmqpHostFtr(String amqpHostFtr) {
        this.amqpHostFtr = amqpHostFtr;
    }
    //AMQポート(SMFL/みらい)
    public String getAmqpPortSmfl() {
        return amqpPortSmfl;
    }
    public void setAmqpPortSmfl(String amqpPortSmfl) {
        this.amqpPortSmfl = amqpPortSmfl;
    }
    
    public String getAmqpPortFtr() {
        return amqpPortFtr;
    }
    public void setAmqpPortFtr(String amqpPortFtr) {
        this.amqpPortFtr = amqpPortFtr;
    }
    //ユーザー名(SMFL/みらい)
    public String getUserNameSmfl() {
        return userNameSmfl;
    }
    public void setUserNameSmfl(String userNameSmfl) {
        this.userNameSmfl = userNameSmfl;
    }
    public String getUserNameFtr() {
        return userNameFtr;
    }
    public void setUserNameFtr(String userNameFtr) {
        this.userNameFtr = userNameFtr;
    }
    //パスワード(SMFL/みらい)
    public String getPassSmfl() {
        return passSmfl;
    }
    public void setPassSmfl(String passSmfl) {
        this.passSmfl = passSmfl;
    }
    public String getPassFtr() {
        return passFtr;
    }
    public void setPassFtr(String passFtr) {
        this.passFtr = passFtr;
    }
    //接続先URI(SMFL/みらい)
    public String getRemoteUriSmfl() {
        return remoteUriSmfl;
    }
    public void setRemoteUriSmfl(String remoteUriSmfl) {
        this.remoteUriSmfl = remoteUriSmfl;
    }
    public String getRemoteUriFtr() {
        return remoteUriFtr;
    }
    public void setRemoteUriFtr(String remoteUriFtr) {
        this.remoteUriFtr = remoteUriFtr;
    }


    //AMQ接続情報設定処理(SMFL)
    @Bean
    public org.apache.qpid.jms.JmsConnectionFactory amqpConnectionFactorySmfl() {
        org.apache.qpid.jms.JmsConnectionFactory JmsConnectionFactory = new JmsConnectionFactory();
        JmsConnectionFactory.setRemoteURI(remoteUriSmfl);
        //TODO
        JmsConnectionFactory.setUsername(userNameSmfl);
        JmsConnectionFactory.setPassword(passSmfl);
        return JmsConnectionFactory;
    }

    //AMQ接続情報設定処理(みらい)
    @Bean
    public org.apache.qpid.jms.JmsConnectionFactory amqpConnectionFactoryFtr() {
        org.apache.qpid.jms.JmsConnectionFactory JmsConnectionFactory = new JmsConnectionFactory();
        JmsConnectionFactory.setRemoteURI(remoteUriFtr);
        //TODO
        JmsConnectionFactory.setUsername(userNameFtr);
        JmsConnectionFactory.setPassword(passFtr);
        return JmsConnectionFactory;
    }


}
