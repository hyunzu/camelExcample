package camel;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.support.MessageHelper;
import org.apache.camel.support.processor.DefaultExchangeFormatter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CreateErrorResponse implements Processor {

    Logger logger = LoggerFactory.getLogger(CreateErrorResponse.class);

    @Override
    public void process(Exchange exchange) throws Exception {

        //エラー時のログ設定をロガー設定に反映する。
        DefaultExchangeFormatter historyFormatter;
        historyFormatter = new DefaultExchangeFormatter();
        historyFormatter.setShowAll(true);
        historyFormatter.setMultiline(true);
        historyFormatter.setStyle(DefaultExchangeFormatter.OutputStyle.Fixed);
        logger.error(MessageHelper.dumpMessageHistoryStacktrace(exchange, historyFormatter, true));

        //Exceptionを取得する
        Exception e = exchange.getException();
        if(e == null) {
            e = exchange.getProperty(Exchange.EXCEPTION_CAUGHT, Exception.class);
        }
        //Exception情報が取得できない場合
        if(e == null) {
            //ヘッダ情報の削除
            exchange.getIn().removeHeader("*");
            //500 Internal Server Errorのレスポンスを設定
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 500);
            exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
            exchange.getIn().setBody("{\"message\": \"Internal Server Error\"}");
        }
        //Exception情報が取得できた場合
        else {
            //エラーメッセージを取得する
            String message = e.getMessage();
            Throwable cause = e.getCause();
            //エラー原因が取得できる場合
            if(cause != null) {
                //エラーメッセージにエラー原因を追加する
                message += ", " + cause.getMessage();
            }
            //エラーメッセージ内に"timeout"という文言が含まれている場合
            if(message.toLowerCase().contains("timeout")){
                //ヘッダ情報の削除
                exchange.getIn().removeHeader("*");
                //504 Gateway Time-outのレスポンス設定
                exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 504);
                exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
                exchange.getIn().setBody("{\"message\": \"Gateway Time-out\"}");
            }
            //エラーメッセージ内に"timeout"という文言が含まれていない場合
            else {
                //ヘッダ情報の削除
                exchange.getIn().removeHeader("*");
                //500 Internal Server Errorのレスポンスを設定
                exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, 500);
                exchange.getIn().setHeader(Exchange.CONTENT_TYPE, "application/json");
                exchange.getIn().setBody("{\"message\": \"Internal Server Error\"}");
            }

        }
    }
    
    
}
